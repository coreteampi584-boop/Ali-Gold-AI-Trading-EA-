ALI SHAH GOLD EA — STARTER WEBSITE

This is a static starter website. Before publishing:
1. Open index.html and replace sample product names, descriptions and prices.
2. Add your USDT BEP20 receiving address in the payment section.
3. Create a Google Form for order submissions with fields:
   - Customer name
   - Email address
   - EA product
   - MT5 account number
   - Broker/server name
   - USDT amount sent
   - Transaction ID (TXID)
   - Payment screenshot (File upload)
4. Set the Google Form file-upload settings. Google may require customers to sign in.
5. Replace the Google Forms button URL in index.html with your actual form share URL.
6. Do not put EA .mq5/.ex5 files, private keys, seed phrases or passwords in this website repository.
7. This static website does not automatically receive or store order submissions. Google Forms is a separate order intake step.
8. For manual license delivery, verify the transaction on BNB Smart Chain and check the received amount before emailing the EA.
9. One-license-per-MT5-account enforcement must be implemented in the EA itself; this website wording alone does not enforce it.

Mobile publishing:
- Cloudflare Pages supports deploying a static site from uploaded assets depending on the current dashboard flow. Upload the site files (index.html and README.txt) or a ZIP if the dashboard offers that option.
- GitHub Pages may also work without GitHub Actions if repository Pages settings allow a branch-based deployment.
